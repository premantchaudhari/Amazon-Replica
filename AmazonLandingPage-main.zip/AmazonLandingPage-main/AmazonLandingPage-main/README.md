# Prabhat's Amazon Landing Page - TECHNOHACKS

Landing Page at TechnoHacks

# Prabhat Sharma

Hello connections,

I'm excited to share #task1 of my internship with The TECHNOHACKS EDUTECH in Web development under the Technohacks - 'Lets Grow Together' Program

#BATCH8

Task:Landing Page

IDE: VSCODE

## Technologies Used:
- HTML
- CSS

GitHub Repository Link:https://github.com/prabhatrsharma/TechnoHacks-AmazonLandingPage.git

Hosted Website Link: [https://prabharsharma.github.io/TechnoHacks-AmazonLandingPage/](https://prabhatrsharma.github.io/TechnoHacks-AmazonLandingPage/)

To know MORE about TECHNOHACKS EDUTECH Website: 

http://technohacks.co.in/

VISIT Technohacks Edutech: 
<a href="https://www.linkedin.com/company/technohacks-edutech/"> Linkedin</a>||
<a href="https://twitter.com/technohacksedu"> Twitter</a>||
<a href="https://telegram.me/TechnoHacksofficial"> Telegram</a>||
<a href="https://www.instagram.com/technohacks.co.in"> Instagram</a>||
<a href="https://www.youtube.com/channel/UCwuh25VS9J9ApJ7Yomw_Lqw"> Youtube</a>||<br>

Thanking,
Techno Hacks:
Mr. Sandip Gavit

Please review and comment with your worthy suggestions.

![image](https://github.com/prabhatrsharma/amazonClone/assets/118990267/4c417a51-cbd5-4a01-b1f1-bdf33471f28b)

Thank You!!!

- Prabhat Sharma
